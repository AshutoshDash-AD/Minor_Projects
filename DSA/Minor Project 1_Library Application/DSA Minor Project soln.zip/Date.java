class Date {
	int dd;
	int mm;
	int yyyy;
	Date(int a,int b,int c){
		dd=a;
		mm=b;
		yyyy=c;
	}
	public int getDD(){
		return dd;
	}
	public int getMM(){
		return mm;
	}
	public int getYYYY(){
		return yyyy;	
	}
    
}
